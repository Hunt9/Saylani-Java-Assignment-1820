package com.company;

/**
 * Created by Champ on 6/18/2016.
 */
public class University {

    String Name = "Sir Syed University Of Engineering & Technology";

    public String getName() {
        return Name;
    }
}
